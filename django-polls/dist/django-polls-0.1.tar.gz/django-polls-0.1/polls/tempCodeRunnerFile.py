            number_of_choices = question.choice_set.count()
